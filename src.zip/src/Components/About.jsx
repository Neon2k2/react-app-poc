export default function AboutUs() {
    return(
        <div>About Us</div>
    )
}


// import React, { useState } from 'react'

// export default function About() {
//     const[count,setCount] = useState(0);
//   return (
//     <div>
//         <p>{count}</p>
//         <button onClick={()=>setCount(count+1)}>Counter</button>
//     </div>
//   )
// }
