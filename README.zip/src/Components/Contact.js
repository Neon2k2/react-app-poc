export default function ContactUs() {
    return(
        <div>Contact Us</div>
    )
}