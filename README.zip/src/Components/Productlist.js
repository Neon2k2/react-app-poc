import React,{useState,useEffect, useContext} from 'react';
import axios from 'axios';
// import productsData from '../Product.json';

import ProductsGrid from './products/ProductsGrid';
import { ProductContext } from './productsContext';

export default function ProductList() {
  const products = useContext(ProductContext);
    // const [products,setProducts]=useState([]);
    // console.log(products)
    // useEffect(()=> {
    //     axios.get('https://fakestoreapi.com/products').then(res=>{
    //         const prod = res.data
    //         setProducts(prod)
    //     })
    // })
    // const [products, setProducts] = useState(productsData.products);
    return(
        <ProductsGrid products={products} />
    )
}