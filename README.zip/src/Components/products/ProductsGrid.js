import React from 'react'
import { useNavigate } from 'react-router-dom'
import ProductItem from './ProductItem'

export default function ProductsGrid({products}) {
    const navigate = useNavigate()

    const createProductLink=()=>{
    navigate("/createproductform");
    }
  return (
    <div className='container'>
        <div className='row'>
            <div className='title-wrapper'>
                <h1 className='page-title'>Products</h1>
                {/* <Link to={'/createproductform'} className="ecomm-link">Create Product</Link> */}
                <button onClick={() => createProductLink()} className="common-btn"  type="submit" >Create Product</button>
            </div>
            <div className='product-list-wrapper'>
                {
                    products?.length > 0 ? products.map(item => (
                        <ProductItem key={item.id} product = {item} />
                    )) : <h5 className='no-data'>No Data Found</h5>

                    // products.map((item)=> <ProductItem key={item.id} product = {item} />)
                }
            </div>
        </div>
    </div>
  )
}
