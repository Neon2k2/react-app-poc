import axios from 'axios';
import React, { createContext, useState, useEffect } from 'react';
 
const ProductContext = createContext();
 
const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
 
  useEffect(() => {
    // Fetch products from API
    axios('https://fakestoreapi.com/products')
    .then(res=>{
       const prod = res.data
                setProducts(prod)
            })
      .catch(error => console.error('Error fetching products:', error));
  }, []);
 
  return (
<ProductContext.Provider value={products}>
      {children}
</ProductContext.Provider>
  );
};
 
export { ProductContext, ProductProvider };