import './App.css';
import './main.scss';
import './_variable.scss';
import Login from './Components/Login';
import AboutUs from "./Components/About";
import ProductDetails from "./Components/Productdetails";
import ProductList from "./Components/Productlist";
import ContactUs from "./Components/Contact";
import CreateProductForm from './Components/CreateProductForm';
import { ProductProvider } from './Components/productsContext';
import {Routes , Route } from "react-router-dom" 
import Main from './Components/Main';

function App() {
  return (
    <div className="App">
      <ProductProvider>
        <Routes>
            <Route path="/" element={<Main><Login /></Main>} />
            <Route path="/product" element={ <Main><ProductList/></Main> } />
            <Route path="/product/:id" element={ <Main><ProductDetails/></Main> } />
            <Route path="/about" element={ <Main><AboutUs/></Main> } />
            <Route path="/contactus" element={ <Main><ContactUs/></Main> } />
            <Route path="/createproductform" element={<Main><CreateProductForm /></Main>} />
        </Routes>
      </ProductProvider>
    </div>
  );
}

export default App;