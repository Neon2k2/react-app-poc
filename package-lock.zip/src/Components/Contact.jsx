export default function ContactUs() {
    return(
        <div>
            <h1>Contact Us</h1>
        </div>
    )
}